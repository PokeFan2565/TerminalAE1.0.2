import time
import os


def timeFilter(time12):
	time12 =	str(time12)
	time12 =	time12.replace('[','')
	time12 =	time12.replace(']', '')
	time12 =	time12.replace("'", '')
	time12 =	time12.replace(",", ':')
	time12 =	time12.replace(" ", '')
	return time12


# This Function Is Return A Dictionary That Contain Day, Month, Date, Time
def clock():
	localTime =	time.asctime(time.localtime(time.time()))
	localTime =	localTime.split(' ')
	timeAndDate =	{ 'Day' : localTime[0], 'Month' : localTime[1], 'Date' : localTime[2], 'Time' : localTime[3].split(':'), 'Year' : localTime[4]}
	return timeAndDate
	
	
# This Function Conver 24 into 12
def timeLogic(time12):
	time12[0] =	int(time12[0])
	if time12[0] >=	13:
		time12[0] =	time12[0] -12
	return time12

# its return current time for example 12:00:01
def currentTime(timeAndDate):
	time12 =	timeAndDate['Time']
	time12 =	timeLogic(time12)
	time12 =	timeFilter(time12)
	return time12
	
'''
This Function Is Use
Fir Printing Day, Date, Month, Time And Year
'''	
def myClock():
	timeAndDate =	clock()
	print('Day   : ', timeAndDate['Day'])
	print('Date  : ', timeAndDate['Date'])
	print('Month : ', timeAndDate['Month'])
	print('Year  : ', timeAndDate['Year'])
	time12 =	currentTime(timeAndDate)
	print('Time  : ', time12)
	time.sleep(0.5)
	
if __name__	==	'__main__':
	while True:
		os.system('clear')
		myClock()