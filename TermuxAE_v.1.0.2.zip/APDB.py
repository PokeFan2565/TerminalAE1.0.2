import json
import os

# For Getting DataBase Path Use This Function
def getDbPath(folderPath, dbName):
	return f'{folderPath}/{dbName}.json'

'''Please Dont Use This Function Its Dengerus it is system define function not for gernal use'''
def writeData(dataBasePath, data):
	with open(dataBasePath, 'w') as f:
		f.write(data)

'''For Creating New DataBase Use This Function note 
that this sample_data is A dictionary give your data in dictionary format replaceing sample_data ex : sample_data =	{'name' : 'APDB'}'''
def makeDataBase(folderPath, dbName, sample_data):
	dbPath = getDbPath(folderPath, dbName)
	if not os.path.exists(folderPath):
		os.system(f'mkdir {folderPath}')
	if not os.path.exists(dbPath):
		sample_data =	parse(sample_data)
		with open(dbPath, 'w') as f:
			f.write(sample_data)
			
'''Please Dont Use This Function Its Dengerus it is system define function not for gernal use'''
def readDataBase(dbPath):
	with open(dbPath, 'r') as f:
		data = f.read()
	try:
		data =	data.replace("'", '"')
		data =	json.loads(data)
	except:
		print('unable to convert single to duble Error Code 01 : ')
	return data
	
	
''' use this function for read your data in readable format'''
def getData(dbPath):
	data =	readDataBase(dbPath)
	data =	parseValue(data)
	return data
	
''' For Saving New Data In Your DataBase Use This Function note 
that this function get only dictionary'''
def enterNewData(dbPath, newData):
	oldData =	readDataBase(dbPath)
	for key in newData:
		oldData[key] = newData[key]
	oldData =	parse(oldData)
	writeData(dbPath, oldData)



'''Please Dont Use This Function Its Dengerus it is system define function not for gernal use'''	
def parse(dict):
	dict =	str(dict)
	dict =	dict.replace("'", '"')
	return dict
	
''' When you get input from the user and going to save it in database please parse it before save it using parseInput() Function'''
def parseInput(input):
	input =	input.replace("'", '&single')
	input =	input.replace('"', '&duble')
	return input
	
	
'''Please Dont Use This Function Its Dengerus it is system define function not for gernal use'''
def parseValue(dict):
	for item in dict:
		try:
			dict[item] =	dict[item].replace('&single', "'")
			dict[item] =	dict[item].replace('&duble', '"')
		except:
			pass
	return dict
	
''' For Showing Main Data Use This'''
def showData(dbPath):
	data =	getData(dbPath)
	for item in data:
		print(f'\033[1;91m{item}\033[1;92m	:	\033[1;91m{data[item]}\033[1;92m')
		
def clearDataBase(dbPath):
	os.system(f'rm -f {dbPath}')
			
if __name__	== '__main__':
	folderPath = '/storage/emulated/0/android/data/APDB'
	dbPath = getDbPath(folderPath, 'report')
	print(dbPath)
	