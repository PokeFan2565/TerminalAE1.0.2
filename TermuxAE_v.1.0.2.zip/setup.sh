termux-setup-storage
pkg install python
pkg install ecj dx
python file.py
cp -f terminalAE.py /data/data/com.termux/files/usr/etc
cp -f help.py /data/data/com.termux/files/usr/etc
cp -f arrow.py /data/data/com.termux/files/usr/etc
rm -f /data/data/com.termux/files/usr/etc/bash.bashrc
cp -f bash.bashrc /data/data/com.termux/files/usr/etc
cp -f admin.py /data/data/com.termux/files/usr/etc
cp -f changePath.py /data/data/com.termux/files/usr/etc
cp -f APDB.py /data/data/com.termux/files/usr/etc
cp -f userManual.py /data/data/com.termux/files/usr/etc
cd uninstall
cp -f uninstall.sh /data/data/com.termux/files/usr/etc/uninstall
cp -f bash.bashrc /data/data/com.termux/files/usr/etc/uninstall