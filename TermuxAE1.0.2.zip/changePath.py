import os


def changePath(userCommand):
	if userCommand[0:2] == 'cd':
		currentPath = os.getcwd()
		destiniPath = f"{currentPath}/{userCommand[3:len(userCommand)]}"
		if os.path.exists(destiniPath):
			os.chdir(destiniPath)
		else:
			print('File Not Found : ')