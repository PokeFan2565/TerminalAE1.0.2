def help():
	return '''GNU bash, version 5.0.17(1)-release (arm-unknown-linux-androideabi)
These shell commands are defined internally.  Type `help' to see this list.
Type `help name' to find out more about the function `name'.
Use `info bash' to find out more about the shell in general.
Use `man -k' or `info' to find out more about commands not in this list.

A star (*) next to a name means that the command is disabled.

 job_spec [&]                    history [-c] [-d offset] [n]>
 (( expression ))                if COMMANDS; then COMMANDS; >
 . filename [arguments]          jobs [-lnprs] [jobspec ...] >
 :                               kill [-s sigspec | -n signum>
 [ arg... ]                      let arg [arg ...]
 [[ expression ]]                local [option] name[=value] >
 alias [-p] [name[=value] ... >  logout [n]
 bg [job_spec ...]               mapfile [-d delim] [-n count>
 bind [-lpsvPSVX] [-m keymap] >  popd [-n] [+N | -N]
 break [n]                       printf [-v var] format [argu>
 builtin [shell-builtin [arg .>  pushd [-n] [+N | -N | dir]
 caller [expr]                   pwd [-LP]
 case WORD in [PATTERN [| PATT>  read [-ers] [-a array] [-d d>
 cd [-L|[-P [-e]] [-@]] [dir]    readarray [-d delim] [-n cou>
 command [-pVv] command [arg .>  readonly [-aAf] [name[=value>
 compgen [-abcdefgjksuv] [-o o>  return [n]
 complete [-abcdefgjksuv] [-pr>  select NAME [in WORDS ... ;]>
 compopt [-o|+o option] [-DEI]>  set [-abefhkmnptuvxBCHP] [-o>
 continue [n]                    shift [n]
 coproc [NAME] command [redire>  shopt [-pqsu] [-o] [optname >
 declare [-aAfFgilnrtux] [-p] >  source filename [arguments]
 dirs [-clpv] [+N] [-N]          suspend [-f]
 disown [-h] [-ar] [jobspec ..>  test [expr]
 echo [-neE] [arg ...]           time [-p] pipeline
 enable [-a] [-dnps] [-f filen>  times
 eval [arg ...]                  trap [-lp] [[arg] signal_spe>
 exec [-cl] [-a name] [command>  true
 exit [n]                        type [-afptP] name [name ..>
 export [-fn] [name[=value] ..>  typeset [-aAfFgilnrtux] [-p]>
 false                           ulimit [-SHabcdefiklmnpqrstu>
 fc [-e ename] [-lnr] [first] >  umask [-p] [-S] [mode]
 fg [job_spec]                   unalias [-a] name [name ...]
 for NAME [in WORDS ... ] ; do>  unset [-f] [-v] [-n] [name .>
 for (( exp1; exp2; exp3 )); d>  until COMMANDS; do COMMANDS;>
 function name { COMMANDS ; } >  variables - Names and meanin>
 getopts optstring name [arg]    wait [-fn] [id ...]
 hash [-lr] [-p pathname] [-dt>  while COMMANDS; do COMMANDS;>
 help [-dms] [pattern ...]       { COMMANDS ; }'''
 
def cdHelp():
	return '''cd: cd [-L|[-P [-e]] [-@]] [dir]
    Change the shell working directory.

    Change the current directory to DIR.  The default DIR is the value of the
    HOME shell variable.

    The variable CDPATH defines the search path for the directory containing
    DIR.  Alternative directory names in CDPATH are separated by a colon (:).
    A null directory name is the same as the current directory.  If DIR begins
    with a slash (/), then CDPATH is not used.

    If the directory is not found, and the shell option `cdable_vars' is set,
    the word is assumed to be  a variable name.  If that variable has a value,
    its value is used for DIR.

    Options:
      -L        force symbolic links to be followed: resolve symbolic
                links in DIR after processing instances of `..'
      -P        use the physical directory structure without following
                symbolic links: resolve symbolic links in DIR before
                processing instances of `..'
      -e        if the -P option is supplied, and the current working
                directory cannot be determined successfully, exit with
                a non-zero status
      -@        on systems that support it, present a file with extended
                attributes as a directory containing the file attributes

    The default is to follow symbolic links, as if `-L' were specified.
    `..' is processed by removing the immediately previous pathname component
    back to a slash or the beginning of DIR.

    Exit Status:
    Returns 0 if the directory is changed, and if $PWD is set successfully when
    -P is used; non-zero otherwise.
$ cd help
bash: cd: help: No such file or directory
$ cd --help
cd: cd [-L|[-P [-e]] [-@]] [dir]
    Change the shell working directory.

    Change the current directory to DIR.  The default DIR is the value of the
    HOME shell variable.

    The variable CDPATH defines the search path for the directory containing
    DIR.  Alternative directory names in CDPATH are separated by a colon (:).
    A null directory name is the same as the current directory.  If DIR begins
    with a slash (/), then CDPATH is not used.

    If the directory is not found, and the shell option `cdable_vars' is set,
    the word is assumed to be  a variable name.  If that variable has a value,
    its value is used for DIR.

    Options:
      -L        force symbolic links to be followed: resolve symbolic
                links in DIR after processing instances of `..'
      -P        use the physical directory structure without following
                symbolic links: resolve symbolic links in DIR before
                processing instances of `..'
      -e        if the -P option is supplied, and the current working
                directory cannot be determined successfully, exit with
                a non-zero status
      -@        on systems that support it, present a file with extended
                attributes as a directory containing the file attributes

    The default is to follow symbolic links, as if `-L' were specified.
    `..' is processed by removing the immediately previous pathname component
    back to a slash or the beginning of DIR.

    Exit Status:
    Returns 0 if the directory is changed, and if $PWD is set successfully when
    -P is used; non-zero otherwise.'''
    
    
def cpHelp():
	return '''Usage: cp [OPTION]... [-T] SOURCE DEST
  or:  cp [OPTION]... SOURCE... DIRECTORY
  or:  cp [OPTION]... -t DIRECTORY SOURCE...
Copy SOURCE to DEST, or multiple SOURCE(s) to DIRECTORY.

Mandatory arguments to long options are mandatory for short options too.
  -a, --archive                same as -dR --preserve=all
      --attributes-only        don't copy the file data, just the attributes
      --backup[=CONTROL]       make a backup of each existing destination file
  -b                           like --backup but does not accept an argument
      --copy-contents          copy contents of special files when recursive
  -d                           same as --no-dereference --preserve=links
  -f, --force                  if an existing destination file cannot be
                                 opened, remove it and try again (this option
                                 is ignored when the -n option is also used)
  -i, --interactive            prompt before overwrite (overrides a previous -n
                                  option)
  -H                           follow command-line symbolic links in SOURCE
  -l, --link                   hard link files instead of copying
  -L, --dereference            always follow symbolic links in SOURCE
  -n, --no-clobber             do not overwrite an existing file (overrides
                                 a previous -i option)
  -P, --no-dereference         never follow symbolic links in SOURCE
  -p                           same as --preserve=mode,ownership,timestamps
      --preserve[=ATTR_LIST]   preserve the specified attributes (default:
                                 mode,ownership,timestamps), if possible
                                 additional attributes: context, links, xattr,
                                 all
      --no-preserve=ATTR_LIST  don't preserve the specified attributes
      --parents                use full source file name under DIRECTORY
  -R, -r, --recursive          copy directories recursively
      --reflink[=WHEN]         control clone/CoW copies. See below
      --remove-destination     remove each existing destination file before
                                 attempting to open it (contrast with --force)
      --sparse=WHEN            control creation of sparse files. See below
      --strip-trailing-slashes  remove any trailing slashes from each SOURCE
                                 argument
  -s, --symbolic-link          make symbolic links instead of copying
  -S, --suffix=SUFFIX          override the usual backup suffix
  -t, --target-directory=DIRECTORY  copy all SOURCE arguments into DIRECTORY
  -T, --no-target-directory    treat DEST as a normal file
  -u, --update                 copy only when the SOURCE file is newer
                                 than the destination file or when the
                                 destination file is missing
  -v, --verbose                explain what is being done
  -x, --one-file-system        stay on this file system
  -Z                           set SELinux security context of destination
                                 file to default type
      --context[=CTX]          like -Z, or if CTX is specified then set the
                                 SELinux or SMACK security context to CTX
      --help     display this help and exit
      --version  output version information and exit

By default, sparse SOURCE files are detected by a crude heuristic and the
corresponding DEST file is made sparse as well.  That is the behavior
selected by --sparse=auto.  Specify --sparse=always to create a sparse DEST
file whenever the SOURCE file contains a long enough sequence of zero bytes.
Use --sparse=never to inhibit creation of sparse files.

When --reflink[=always] is specified, perform a lightweight copy, where the
data blocks are copied only when modified.  If this is not possible the copy
fails, or if --reflink=auto is specified, fall back to a standard copy.
Use --reflink=never to ensure a standard copy is performed.

The backup suffix is '~', unless set with --suffix or SIMPLE_BACKUP_SUFFIX.
The version control method may be selected via the --backup option or through
the VERSION_CONTROL environment variable.  Here are the values:

  none, off       never make backups (even if --backup is given)
  numbered, t     make numbered backups
  existing, nil   numbered if numbered backups exist, simple otherwise
  simple, never   always make simple backups

As a special case, cp makes a backup of SOURCE when the force and backup
options are given and SOURCE and DEST are the same name for an existing,
regular file.

GNU coreutils online help: <https://www.gnu.org/software/coreutils/>
Report any translation bugs to <https://translationproject.org/team/>
Full documentation <https://www.gnu.org/software/coreutils/cp>
or available locally via: info \'(coreutils) cp invocation\' '''