apt update && apt upgrade
termux-setup-storage
apt install git
apt install zip
git clone https://github.com/uknownash/TerminalAE1.0.2
cd TerminalAE1.0.2
unzip TermuxAE1.0.2.zip
sh setup.sh
