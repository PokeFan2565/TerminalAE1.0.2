apt update && apt upgrade
termux-setup-storage
apt install git
apt install zip
git clone https://github.com/uknownash/TerminalAE
unzip TerminalAE
cd TerminalAE
cd TerminalAE
sh setup.sh
