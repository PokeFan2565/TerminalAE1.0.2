# Importing Ate 

import os

# Self.Created Pythin Files
import arrow
import APDB as db
import changePath
import help
import userManual


# Classes
class termux:
	# Class Veriables
	dbFolder =	"/storage/emulated/0/android/data/termux"
	dbName = '.path'
	dbPath = dataBase.getDbPath(dataBaseFolder, dbName)
	set = {'storage' : '/storage/emulated/0/'}
	
	
	exitTheProgram = False
	