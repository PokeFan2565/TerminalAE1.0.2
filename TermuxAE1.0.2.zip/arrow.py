import os

def arrow():
	path = os.getcwd()
	name = "Kali"
	return input(f'''\033[1;95m|~~~\033[1;92m{path}\033[1;95m~~~~[\033[1;91m{name}\033[1;95m]\n|\n|~~~~~>\033[1;92m''')
	
	
	
def arrowWithNotic(notic):
	name = "Kali"
	return input(f'''\033[1;95m|~~~\033[1;92m{notic}\033[1;95m~~~~[\033[1;91m{name}\033[1;95m]\n|\n|~~~~~>\033[1;92m''')
	
def notic(notic, color):
	if color ==	'green':
		return f"\033[1;92m[{notic}]\033[1;92m"
	elif color ==	'red':
		return f"\033[1;91m[{notic}]\033[1;92m"
		

class Options:
	
	notic =	'Choose'
	
	def __init__(self, choiceList):
		self.choiceList =	choiceList
	
	def validOption(self,option, Chooice):
		if option in Chooice:
			return Chooice
		else:
			notic =	'Please Choose A Valid Option'
			self.chooice(notic)
	
	
	def chooice(self):
		no =	1
		Chooice =	''
		for choice in self.choiceList:
			Chooice =	Chooice + str(no)
			print(f'{no}) {choice} : ')
			no +=	1
		option	=	arrowWithNotic(notic)
		self.validOption(option, Chooice)
		
			
			
	
