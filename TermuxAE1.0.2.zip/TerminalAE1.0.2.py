# Importing Ate 

import os

# Self.Created Pythin Files
import arrow as ar
import APDB as db
import changePath
import help
import userManual
import clock
import keyword


# Classes

class termux:
	
	# Class Veriables
	
	dbFolder =	"/storage/emulated/0/android/data/termux"
	dbName = '.path'
	dbPath = db.getDbPath(dbFolder, dbName)
	set = {'storage' : '/storage/emulated/0/'}
	
	adminChoice =	['Path Setting', 'Main Settings']
	
	history =	''
	
	exitTheProgram = False
	
	#----------------------
	
	
	# Functions :-----
	
	
		
	
	
	
	
	#---------------------
	
	
	
	#Coding Area -->


	os.chdir('/storage/emulated/0')
	os.system('clear')
	getOption =	ar.Options(adminChoice)
	
		
	#---------------------
		
		
	db.makeDataBase(dbFolder, dbName, set)
	
	# Starting Loop
	
	while not exitTheProgram:
		cmd = ar.arrow()
		history =	cmd
		if cmd ==	'time':
			clock.myClock()
		elif cmd ==	'admin':
			choice =	getOption.chooice()
			print(choice)
		
	
	#----------------------
	