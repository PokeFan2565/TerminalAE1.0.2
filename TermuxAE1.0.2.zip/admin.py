
# Importing Are


import os
import APDB as dataBase
import arrow
import hashlib





# Veriables
dbFolder =	"/storage/emulated/0/Android/data/termux"
dbName = '.settings'
dbPath =	dataBase.getDbPath(dbFolder, dbName)
hash =	hashlib.sha256('termux'.encode('utf-8')).hexdigest()
set =	{'password' : hash }
dataBase.makeDataBase(dbFolder, dbName, set)
	
	
def main():
	
	# Veriables
	
	
	folderPath =	"/storage/emulated/0/Android/data/termux"
	firstData = {'cl' : 'clear'}
	gameOver =	False
	dbName =	'.path'
	settingDbPath = dataBase.getDbPath(folderPath, '.settings')
	dataBasePath = dataBase.getDbPath(folderPath, dbName)
	
	
	# Body
	
	
	
	
	dataBase.makeDataBase(folderPath, dbName, firstData)
	while not gameOver:
		newData =	{}
		password =	arrow.arrowWithNotic('Enter Your Password : ')
		verify =	auth(settingDbPath, password)
		if verify == True:
			fileName = arrow.arrowWithNotic('Enter Your File Name : ')
			filePath = arrow.arrowWithNotic('Enter File Path : ')
			data =	dataBase.getData(dataBasePath)
			fileName =	dataBase.parseInput(fileName)
			filePath =	dataBase.parseInput(filePath)
			newData[fileName] = filePath
			dataBase.enterNewData(dataBasePath, newData)
			print(arrow.notic('Data Updated Sucessfully :\nEnter Any Key To Exit.', 'green'))
			input()
			gameOver =	True
		else:
			gameOver =	True
		
def auth(dbPath, password):
	data =	dataBase.getData(dbPath)
	hash =	hashlib.sha256(password.encode('utf-8')).hexdigest()
	if data['password'] ==	hash:
		return True
	else:
		return False
			
def setting():
	
	global dbFolder, dbName, dbPath, hash, set
	
	# Main Word
	
	print('1) Change Password : ')
	choose =	input()
	if choose ==	'1':
		password =	input('Please Enter Current Password : ')
		verify =	auth(dbPath, password)
		if verify ==	True:
			newPassword =	input('Enter New Password : ')
			newPassword =	dataBase.parseInput(newPassword)
			newHash = hashlib.sha256(newPassword.encode('utf-8')).hexdigest()
			set =	{ 'password' :	newHash }
			dataBase.enterNewData(dbPath, set)
		else:
			print('You Have Entered Wrong Password : ')

