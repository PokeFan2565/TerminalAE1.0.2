
# Importing Area -->

import os


# Self Created Files
import arrow
import changePath
import help
import admin
import APDB as  dataBase
import userManual
import clock

# Globle Veriables

dataBaseFolder =	"/storage/emulated/0/android/data/termux"
dbName = '.path'
dataBasePath = dataBase.getDbPath(dataBaseFolder, dbName)
firstData = {'storage' : '/storage/emulated/0/'}



exitTheProgram = False


#Coding Area -->


os.chdir('/storage/emulated/0')
os.system('clear')

	
	
	
dataBase.makeDataBase(dataBaseFolder, dbName, firstData)



while not exitTheProgram:
	try:
		data =	dataBase.getData(dataBasePath)
	except:
		print('Unable To Read Data')
	userCommand =arrow.arrow()
	changePath.changePath(userCommand)
	if userCommand =='help':
		print(help.help())
	elif userCommand == 'cd --help':
		print(help.cdHelp())
	elif userCommand == 'cp --help':
		print(help.cpHelp())
	elif userCommand == 'termux --plugin --version':
		print('Turmux Admin Edition(AE) V.1.0')
	elif userCommand == 'termux --plugin --owner':
		print('Termux Admin Edition(AE) Version v.1.0 \n')
		print('\tCreated By Alok Mistry :\n')
		print('Email :- alokmistry79@gmail.com')
	elif userCommand == 'admin':
		print('1) Path Setting : ')
		print('2) Main Setting : ')
		choose =	arrow.arrowWithNotic('Choose 1 Or 2 ')
		if choose ==	'1':
			admin.main()
		elif choose ==	'2':
			admin.setting()
	elif userCommand ==	'showdata':
		dataBase.showData(dataBasePath)
	elif userCommand ==	'advance command':
		print(userManual.userManual())
	elif userCommand ==	'exit':
		exitTheProgram =	True
	elif userCommand == "uninstall":
		os.system("sh /data/data/com.termux/files/usr/etc/uninstall/uninstall.sh")
	elif userCommand ==	'termux':
		os.chdir('/data/data/com.termux/files/home')
	elif userCommand ==	'sdcard':
		os.chdir('/storage/emulated/0')
	elif userCommand ==	'cleardata':
		dataBase.clearDataBase(dataBasePath)
		dataBase.makeDataBase(dataBaseFolder, dbName, firstData)
	elif userCommand ==	'time':
		clock.myClock()
	else:
		if userCommand[0:2] != 'cd':
			if userCommand in data:
				os.chdir(data[userCommand])
			else:
				try:
					os.system(userCommand)
				except:
					print('Uknown Command : ')
					
	

