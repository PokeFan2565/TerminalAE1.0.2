
import os

print('Checking Old Version : ')

if not os.path.exists("/data/data/com.termux/files/usr/etc/uninstall"):
	print('You Have Not Installed Termux Plugin Before It : ')
	os.mkdir("/data/data/com.termux/files/usr/etc/uninstall")
else:
	print('Old Version Found : ')
	if os.path.exists('/data/data/com.termux/files/usr/etc/uninstall/uninstall.sh'):
		print('Trying To Uninstall Old Version Way 1 : ')
		os.system("sh /data/data/com.termux/files/usr/etc/uninstall/uninstall.sh")
		print('Old Verion Uninstalled SucessFully Way 1')
	else:
		print('Trying To Uninstall Old Version Way 2 : ')
		os.system('sh uninstall/uninstall.sh')
		print('Old Verion Uninstalled SucessFully Way 1')